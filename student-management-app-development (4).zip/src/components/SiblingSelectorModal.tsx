import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Users, BookOpen, Check, AlertTriangle, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface SiblingSelectorModalProps {
  currentStudentId: string | null;
  selectedSiblingIds: string[];
  onConfirm: (siblingIds: string[]) => void;
  onClose: () => void;
}

export default function SiblingSelectorModal({
  currentStudentId,
  selectedSiblingIds,
  onConfirm,
  onClose,
}: SiblingSelectorModalProps) {
  const { students } = useApp();
  const [selectedClass, setSelectedClass] = useState<number | null>(null);
  const [tempSelectedIds, setTempSelectedIds] = useState<string[]>([...selectedSiblingIds]);
  const [showConfirm, setShowConfirm] = useState(false);

  // Filter out current student and already selected siblings from other classes
  const availableStudents = students.filter(
    (s) => s.id !== currentStudentId && !selectedSiblingIds.includes(s.id)
  );

  const classesWithStudents = Array.from(
    new Set(availableStudents.map((s) => s.classId))
  ).sort((a, b) => a - b);

  const studentsInSelectedClass = selectedClass
    ? availableStudents.filter((s) => s.classId === selectedClass)
    : [];

  const toggleStudent = (id: string) => {
    setTempSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((sid) => sid !== id) : [...prev, id]
    );
  };

  const newlySelected = tempSelectedIds.filter((id) => !selectedSiblingIds.includes(id));
  const removedSelected = selectedSiblingIds.filter((id) => !tempSelectedIds.includes(id));

  const handleProceed = () => {
    if (newlySelected.length === 0 && removedSelected.length === 0) {
      onClose();
      return;
    }
    setShowConfirm(true);
  };

  const handleConfirm = () => {
    onConfirm(tempSelectedIds);
    setShowConfirm(false);
    onClose();
  };

  const getInitials = (name: string) =>
    name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[85vh] overflow-hidden flex flex-col"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between flex-shrink-0">
            <h2 className="text-xl font-bold text-slate-900">Add Siblings</h2>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Selected count */}
            {tempSelectedIds.length > 0 && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 text-white">
                <Users className="w-4 h-4" />
                <span className="text-sm font-medium">
                  {tempSelectedIds.length} sibling{tempSelectedIds.length !== 1 ? 's' : ''} selected
                </span>
              </div>
            )}

            {/* Class Selection */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Select Class
              </label>
              <div className="grid grid-cols-4 gap-2">
                {classesWithStudents.length === 0 ? (
                  <p className="col-span-4 text-sm text-slate-400 py-4 text-center bg-slate-50 rounded-xl">
                    No other students available
                  </p>
                ) : (
                  classesWithStudents.map((cls) => (
                    <button
                      key={cls}
                      type="button"
                      onClick={() => setSelectedClass(selectedClass === cls ? null : cls)}
                      className={`flex flex-col items-center gap-1 py-3 rounded-xl border-2 font-medium text-sm transition-all cursor-pointer ${
                        selectedClass === cls
                          ? 'border-slate-900 bg-slate-900 text-white'
                          : 'border-slate-200 text-slate-700 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>Class {cls}</span>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Students in selected class */}
            <AnimatePresence>
              {selectedClass && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2"
                >
                  <label className="block text-sm font-medium text-slate-700">
                    Students in Class {selectedClass}
                  </label>
                  {studentsInSelectedClass.length === 0 ? (
                    <p className="text-sm text-slate-400 py-3 px-4 bg-slate-50 rounded-xl">
                      No students in this class
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto rounded-xl border border-slate-200 p-2">
                      {studentsInSelectedClass.map((s) => {
                        const isSelected = tempSelectedIds.includes(s.id);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => toggleStudent(s.id)}
                            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors cursor-pointer text-left ${
                              isSelected
                                ? 'bg-slate-900 text-white'
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <div
                              className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden ${
                                isSelected ? 'bg-white/20' : 'bg-slate-100'
                              }`}
                            >
                              {s.photo ? (
                                <img
                                  src={s.photo}
                                  alt={s.name}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <span
                                  className={`text-xs font-bold ${
                                    isSelected ? 'text-white' : 'text-slate-400'
                                  }`}
                                >
                                  {getInitials(s.name)}
                                </span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-sm truncate">{s.name}</div>
                              <div
                                className={`text-xs ${
                                  isSelected ? 'text-white/70' : 'text-slate-400'
                                }`}
                              >
                                Class {s.classId}
                              </div>
                            </div>
                            {isSelected && (
                              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                                <Check className="w-3.5 h-3.5 text-white" />
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-slate-100 flex gap-3 flex-shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleProceed}
              className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white font-medium hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {newlySelected.length > 0 || removedSelected.length > 0
                ? `Save (${tempSelectedIds.length})`
                : 'Save'}
            </button>
          </div>
        </motion.div>
      </motion.div>

      {/* Confirmation */}
      <AnimatePresence>
        {showConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6"
            >
              <div className="flex items-center justify-center mb-4">
                <div className="w-14 h-14 rounded-full bg-amber-100 flex items-center justify-center">
                  <AlertTriangle className="w-7 h-7 text-amber-600" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-slate-900 text-center mb-2">
                Confirm Sibling Links?
              </h3>

              {newlySelected.length > 0 && (
                <div className="mb-3">
                  <p className="text-xs font-medium text-emerald-600 mb-1.5 uppercase tracking-wide">
                    Adding
                  </p>
                  <div className="space-y-1">
                    {newlySelected.map((id) => {
                      const s = students.find((st) => st.id === id);
                      return (
                        <div
                          key={id}
                          className="flex items-center gap-2 text-sm text-slate-700"
                        >
                          <User className="w-3.5 h-3.5 text-emerald-500" />
                          <span>
                            {s?.name} <span className="text-slate-400">(Class {s?.classId})</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {removedSelected.length > 0 && (
                <div className="mb-3">
                  <p className="text-xs font-medium text-red-500 mb-1.5 uppercase tracking-wide">
                    Removing
                  </p>
                  <div className="space-y-1">
                    {removedSelected.map((id) => {
                      const s = students.find((st) => st.id === id);
                      return (
                        <div
                          key={id}
                          className="flex items-center gap-2 text-sm text-slate-700"
                        >
                          <User className="w-3.5 h-3.5 text-red-400" />
                          <span>
                            {s?.name} <span className="text-slate-400">(Class {s?.classId})</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <p className="text-sm text-slate-500 text-center mb-6">
                Total siblings after save:{' '}
                <strong>{tempSelectedIds.length}</strong>
              </p>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={handleConfirm}
                  className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white font-medium hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
