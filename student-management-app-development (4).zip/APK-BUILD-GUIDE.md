# Target Classes — APK Build Guide

## Prerequisites

1. **Node.js** (v18 or higher)
2. **Java JDK** (v17) — `sudo apt install openjdk-17-jdk` (Linux) or download from Oracle
3. **Android Studio** — Download from https://developer.android.com/studio
4. **Android SDK** — Installed via Android Studio

## Environment Setup

### 1. Install Android Studio
Download and install Android Studio from:
https://developer.android.com/studio

### 2. Set Environment Variables

**Linux/Mac:**
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
```

**Windows:**
Add to System Environment Variables:
- `ANDROID_HOME` = `C:\Users\YOUR_NAME\AppData\Local\Android\Sdk`
- Add to `PATH`: `%ANDROID_HOME%\platform-tools`

### 3. Accept Android Licenses
```bash
sdkmanager --licenses
```

## Build APK

### Option A: One-Command Build (Recommended)

```bash
# Make script executable
chmod +x android-build.sh

# Run the build
./android-build.sh
```

### Option B: Manual Step-by-Step

```bash
# Step 1: Build web app
npm run build

# Step 2: Add Android platform (first time only)
npx cap add android

# Step 3: Sync web assets
npx cap sync android

# Step 4: Build debug APK
cd android
./gradlew assembleDebug
```

## APK Output Location

```
android/app/build/outputs/apk/debug/app-debug.apk
```

## Install on Phone

### Via USB (ADB):
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### Via File Transfer:
1. Copy `app-debug.apk` to your phone
2. Open the file on your phone
3. Allow "Install from unknown sources" if prompted
4. Install

## Build Release APK (For Play Store)

```bash
cd android
./gradlew assembleRelease
```

Release APK location:
```
android/app/build/outputs/apk/release/app-release-unsigned.apk
```

## Open in Android Studio

```bash
npx cap open android
```

This opens the project in Android Studio where you can:
- Build APK with GUI
- Run on emulator
- Debug
- Sign release builds

## Firebase Setup for APK

Since the app uses Firebase Authentication, you need to add your app's SHA-1 fingerprint to Firebase Console:

1. Get debug SHA-1:
```bash
cd android
./gradlew signingReport
```

2. Copy the `SHA1` value under `Variant: debug`

3. Go to Firebase Console → Project Settings → Android Apps → Add SHA-1

4. Download `google-services.json` and place it in:
```
android/app/google-services.json
```

5. Rebuild:
```bash
npx cap sync android
cd android && ./gradlew assembleDebug
```

## Troubleshooting

### "SDK not found"
Make sure `ANDROID_HOME` is set correctly.

### "Java version mismatch"
Install JDK 17:
```bash
# Ubuntu/Debian
sudo apt install openjdk-17-jdk

# Mac
brew install openjdk@17
```

### "Gradle build failed"
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

### Firebase Auth not working in APK
Make sure you added the SHA-1 fingerprint to Firebase Console and downloaded `google-services.json`.
